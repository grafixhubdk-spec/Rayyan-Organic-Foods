Rayyan Organic Foods - Android Studio Project

اہم:
یہ Android WebView wrapper project ہے۔ اس میں آپ کا موجودہ interactive HTML store شامل ہے۔
یہ APK خود نہیں ہے؛ اس فولڈر کو Android Studio میں کھول کر APK build کرنا ہوگا۔

APK بنانے کا طریقہ:
1) کمپیوٹر پر Android Studio انسٹال کریں۔
2) Android Studio میں Open منتخب کریں اور یہ project folder کھولیں۔
3) Gradle sync مکمل ہونے دیں (انٹرنیٹ درکار ہو سکتا ہے)۔
4) Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
5) APK عام طور پر app/build/outputs/apk/debug/app-debug.apk میں بنے گی۔
6) APK اپنے Android/Vivo فون میں منتقل کرکے انسٹال کریں۔ فون میں unknown-app installation کی اجازت درکار ہو سکتی ہے۔

Demo کی حدود:
- Admin orders اسی فون/ایپ کے local storage میں رہتے ہیں؛ دوسرے فون یا کمپیوٹر پر sync نہیں ہوتے۔
- Admin login/password موجود نہیں؛ اسے حقیقی کاروبار میں استعمال نہ کریں۔
- Online payment، cloud database، محفوظ server، live order notifications اور production security ابھی شامل نہیں۔
- WhatsApp لنک فون میں دستیاب براؤزر/WhatsApp کے ذریعے کھلتا ہے۔
- یہ Android project ہے؛ iPhone پر APK انسٹال نہیں ہوتی۔

نیا Admin Panel:
- ایپ میں Header کے Admin بٹن سے لاگ اِن کھولیں۔
- Firebase Authentication میں Email/Password provider فعال ہونا چاہیے۔
- Admin کے Firebase UID کے عین مطابق admins collection میں document بنائیں اور role = admin رکھیں۔
- Firestore Rules فائل میں دیے گئے قواعد Firebase Console > Firestore Database > Rules میں Publish کریں۔
- products collection کے ہر document میں name, en, price, unit, sizes (array of [label,multiplier]), imageUrl (اختیاری) فیلڈز استعمال ہوں گی۔
- orders collection میں ایپ آرڈر خود محفوظ کرے گی؛ WhatsApp کھولنے سے پہلے Firestore save کامیاب ہونا ضروری ہے۔
